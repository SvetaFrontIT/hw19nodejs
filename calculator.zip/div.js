const div = function(a, b) {
    const result = a / b;
    return result;
}
module.exports = div;