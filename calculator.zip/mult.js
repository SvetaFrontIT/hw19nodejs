const mult = function(a, b) {
    const result = a * b;
    return result;
}
module.exports = mult;