const sum = function(a, b) {
    result = a + b;
    return result;
}
module.exports = sum;